from manim import *

class ProjectionExample(ThreeDScene):
    def construct(self):
        # Crear título
        title = Text("Proyección desde Subespacio a Espacio Original")
        title.to_edge(UP)
        self.add_fixed_in_frame_mobjects(title)
        self.play(Write(title))

        # Crear ejes para el subespacio de menor dimensión (2D)
        axes_2d = Axes(
            x_range=[-3, 3], y_range=[-3, 3],
            x_length=5, y_length=5
        ).shift(LEFT * 3)

        # Crear etiquetas para los ejes
        subspace_label = Text("Subespacio de Menor Dimensión").scale(0.7).next_to(axes_2d, DOWN)
        
        # Mostrar los ejes y etiquetas
        self.play(Create(axes_2d), Write(subspace_label))
        self.wait(1)

        # Generar puntos en el subespacio
        np.random.seed(42)
        points_subspace = np.random.randn(10, 2)  # Subespacio de menor dimensión (effective_rank = 2)
        dots_subspace = VGroup(*[
            Dot(axes_2d.coords_to_point(x, y), color=BLUE) for x, y in points_subspace
        ])

        # Mostrar los puntos en el subespacio
        self.play(FadeIn(dots_subspace))
        self.wait(1)

        # Crear ejes para el espacio original en 3D
        axes_3d = ThreeDAxes(
            x_range=[-5, 5], y_range=[-5, 5], z_range=[-5, 5],
            x_length=5, y_length=5, z_length=5
        ).shift(LEFT * 3)

        # Transición de 2D a 3D
        self.play(Transform(axes_2d, axes_3d), FadeOut(subspace_label), run_time=2)
        self.wait(1)

        # Crear etiqueta para el espacio original
        original_label = Text("Espacio Original").scale(0.7).next_to(axes_3d, DOWN)
        self.play(Write(original_label))
        self.wait(1)

        # Crear matriz de proyección
        P = np.random.randn(2, 3)  # Matriz de proyección (effective_rank, n_features)
        points_original = points_subspace @ P  # Proyección al espacio original

        # Generar puntos en el espacio original
        dots_original = VGroup(*[
            Dot3D(axes_3d.coords_to_point(x, y, z), color=RED) for x, y, z in points_original
        ])

        # Mostrar los puntos en el espacio original
        self.play(FadeIn(dots_original))

        # Animar la proyección de cada punto del subespacio al espacio original
        for dot_subspace, dot_original in zip(dots_subspace, dots_original):
            self.play(Transform(dot_subspace.copy(), dot_original), run_time=1)

        # Ocultar los puntos del subespacio
        self.play(FadeOut(dots_subspace))
        self.wait(1)

        # Configurar la cámara 3D
        self.set_camera_orientation(phi=45 * DEGREES, theta=30 * DEGREES)

        # Paneo de la cámara para mostrar la tridimensionalidad
        self.move_camera(phi=45 * DEGREES, theta=-45 * DEGREES, run_time=3)
        self.move_camera(phi=60 * DEGREES, theta=60 * DEGREES, run_time=3)

        # Esperar antes de finalizar
        self.wait(2)

# Para ejecutar este código, guárdalo en un archivo .py y usa el siguiente comando en la terminal:
# manim -ql nombre_del_archivo.py ProjectionExample
