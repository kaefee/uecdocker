from manim import *

class CameraOrientationExample(ThreeDScene):
    def construct(self):
        # Crear un cubo en el centro de la escena
        cube = Cube()
        self.add(cube)

        # Crear texto para los parámetros
        phi_text = Text("phi: 0").to_corner(UL).add_background_rectangle()
        theta_text = Text("theta: 0").next_to(phi_text, DOWN).add_background_rectangle()
        self.add_fixed_in_frame_mobjects(phi_text, theta_text)

        # Función para actualizar el texto
        def update_text(phi, theta):
            phi_text.become(Text(f"phi: {phi}°").to_corner(UL).add_background_rectangle())
            theta_text.become(Text(f"theta: {theta}°").next_to(phi_text, DOWN).add_background_rectangle())
            self.add_fixed_in_frame_mobjects(phi_text, theta_text)

        # Mostrar el cubo con diferentes orientaciones de cámara
        for phi in range(0, 90, 15):
            for theta in range(0, 360, 45):
                self.set_camera_orientation(phi=phi * DEGREES, theta=theta * DEGREES)
                update_text(phi, theta)
                self.wait(1)

# Para ejecutar este código, guárdalo en un archivo .py y usa el siguiente comando en la terminal:
# manim -pql nombre_del_archivo.py CameraOrientationExample
