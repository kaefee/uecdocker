#!/bin/bash

# Crear entorno virtual
python3 -m venv uec_venv

# Activar entorno virtual
source uec_venv/bin/activate

# Instalar dependencias
pip install -r requirements.txt

# Desactivar entorno virtual
deactivate

echo "Setup completed successfully."
