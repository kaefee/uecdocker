from fastapi import FastAPI
from pydantic import BaseModel
import joblib
import pandas as pd

app = FastAPI()

class InputData(BaseModel):
    feature1: float
    feature2: float
    # Añade más características según sea necesario

model = joblib.load('model.joblib')

@app.post("/predict")
def predict(data: InputData):
    df = pd.DataFrame([data.dict()])
    prediction = model.predict(df)
    return {"prediction": prediction[0]}
