-- init.sql

-- Crear la tabla
CREATE TABLE test_data (
    id SERIAL PRIMARY KEY,
    feature1 FLOAT,
    feature2 FLOAT,
    target FLOAT
);

-- Insertar datos de prueba
INSERT INTO test_data (feature1, feature2, target) VALUES
(1.0, 2.0, 3.0),
(4.0, 5.0, 6.0),
(7.0, 8.0, 9.0);
