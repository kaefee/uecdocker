#!/bin/bash

# Nombre del entorno de conda
ENV_NAME=uec_projectenv

# Crear el entorno de conda
conda create --name $ENV_NAME python=3.11 -y

# Activar el entorno de conda
source activate $ENV_NAME

# Instalar dependencias desde el archivo requirements.txt
pip install -r requirements.txt

echo "Setup completed successfully."
echo "To activate the conda environment, use: conda activate $ENV_NAME"
