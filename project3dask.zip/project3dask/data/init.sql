-- init.sql

-- Crear la tabla test_data
CREATE TABLE IF NOT EXISTS test_data (
    id SERIAL PRIMARY KEY,
    feature1 FLOAT,
    feature2 FLOAT,
    target FLOAT
);
