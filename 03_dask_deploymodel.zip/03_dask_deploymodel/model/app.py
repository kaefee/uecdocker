from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import joblib
import pandas as pd

app = FastAPI()

class InputData(BaseModel):
    feature1: float
    feature2: float
    # Añade más características según sea necesario

# Cargar el modelo entrenado
try:
    model = joblib.load('/shared-data/model.joblib')
except Exception as e:
    raise HTTPException(status_code=500, detail=f"Error loading model: {str(e)}")

@app.get("/")
def read_root():
    return {"message": "FastAPI is running"}

@app.post("/predict")
def predict(data: InputData):
    try:
        df = pd.DataFrame([data.dict()])
        prediction = model.predict(df[['feature1', 'feature2']])
        return {"prediction": prediction[0]}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction error: {str(e)}")
